from kivy.uix.screenmanager import Screen

class HomePage(Screen):
    pass
class ColetaPage(Screen):
    pass

class HistoricoPage(Screen):
    pass

class ProdutoPage(Screen):
    pass